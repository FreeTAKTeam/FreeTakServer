from server import startup
import constants
import threading
import queue
q = Queue.Queue()
const = constants.vars()
tcpServerThread = threading.Thread(target = startup, args = (), daemon=True)
tcpServerThread.start()
httpServer