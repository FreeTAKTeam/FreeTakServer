
class dest:
    callsign = ''
    def getcallsign(self):
        return self.callsign

    def setcallsign(self, callsign=0):
        self.callsign = callsign