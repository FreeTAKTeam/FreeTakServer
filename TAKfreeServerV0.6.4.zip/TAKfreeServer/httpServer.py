from flask import Flask, request, send_file #import main Flask class and request object
import zipfile
from werkzeug.datastructures import FileStorage
import os
import sqlite3
from pathlib import Path
import string
import random
import datetime
os.chdir('..')
if os.path.exists('DataPackages')==True:
    pass
elif os.path.exists('DataPackages')==False:
    os.mkdir('DataPackages')
sqliteServer = sqlite3.connect('TAK.db')
cursor = sqliteServer.cursor()

cursor.execute('CREATE TABLE IF NOT EXISTS DataPackages'
                    '(PrimaryKey          INTEGER  PRIMARY KEY ON CONFLICT FAIL AUTOINCREMENT UNIQUE ON CONFLICT FAIL,'
                    'UID                STRING,'
                    'Name               STRING,'
                    'Hash               VARCHAR(300),'
                    'SubmissionDateTime DATETIME DEFAULT (CURRENT_TIMESTAMP),'
                    'SubmissionUser     STRING,'
                    'CreatorUid         STRING,'
                    'Keywords           CHAR     DEFAULT foobar,'
                    'MIMEType           STRING   DEFAULT [application/x-zip-compressed],'
                    'Size               INTEGER);')
sqliteServer.commit()
cursor.close()
sqliteServer.close()
app = Flask(__name__) #create the Flask app


@app.route('/query-example')
def query_example():
    return 'Todo...'

@app.route('/form-example')
def formexample():
    return 'Todo...'

@app.route('/json-example')
def jsonexample():
    return 'Todo...'

@app.route('/Marti/sync/missionupload', methods = ['GET','POST'])
def upload():
    sqliteServer = sqlite3.connect('TAK.db')
    cursor = sqliteServer.cursor()
    if request.method == 'POST':
        hash = request.args.get('hash')
        print(type(hash))
        print(hash)
        letters = string.ascii_letters
        uid = ''.join(random.choice(letters) for i in range(4))
        uid = 'uid-'+str(uid)
        filename = request.args.get('filename')
        creatorUid=request.args.get('creatorUid')
        print(request.form)
        print(request.files.getlist('assetfile'))
        print(type(request.files.getlist('assetfile')))
        file = request.files.getlist('assetfile')
        print(file[0])
        file = file[0]
        if os.path.exists('DataPackages/'+hash)==True:
            pass
        elif os.path.exists('DataPackages/'+hash)==False:
            os.mkdir('DataPackages/'+hash)
        file.save('DataPackages/'+hash+'/'+str(filename)+'.zip')
        fileSize = int(Path('DataPackages/'+hash+'/'+str(filename)+'.zip').stat().st_size)
        cursor.execute("SELECT * FROM sqlite_master WHERE type ='table' AND name NOT LIKE 'sqlite_%';")
        tables = cursor.fetchall()
        print(tables)
        cursor.execute("SELECT Callsign FROM Users WHERE UID=?",(creatorUid,))
        Callsign = cursor.fetchone()
        cursor.execute('INSERT INTO DataPackages (UID, Name, Hash, SubmissionUser, CreatorUid, Size) VALUES(?,?,?,?,?,?);',(uid, filename, str(hash), str(Callsign), str(creatorUid), int(fileSize),))
        sqliteServer.commit()
        cursor.close()
        sqliteServer.close()
        return '200'

@app.route('/Marti/api/sync/metadata/<hash>/tool', methods = ['GET','POST', 'PUT'])
def theUploadPart2(hash):
    if request.method == 'PUT':
        print(request.data)
        data = getAllPackages()
        return '200'
    else:
        return 'other'
@app.route('/Marti/sync/search')
def retrieveData():
    keyword = request.args.get('keyword')
    Packages = getAllPackages()
    print(Packages)
    return str(Packages)
    
@app.route('/Marti/sync/content')
def specificPackage():
    hash = request.args.get('hash')
    print(os.listdir('DataPackages/'+str(hash)))
    file_list=os.listdir('DataPackages/'+str(hash))

    print('DataPackages/'+hash+'/'+file_list[0])
    dir = os.getcwd()
    return send_file(str(str(dir)+'\\DataPackages\\'+str(hash)+'\\'+file_list[0]))

@app.route('/Marti/api/version')
def returnVersion():
    VersionData='FreeTAKServer'
    return VersionData

@app.route('/Marti/sync/missionquery')
def checkPresent():
    hash = request.args.get('hash')
    present = getSpecific(hash)
    if present == True:
        return '200'
    elif present == False:
        return '404', 404


def getSpecific(hash):
    sqliteServer = sqlite3.connect('TAK.db')
    cursor = sqliteServer.cursor()
    cursor.execute("SELECT * FROM DataPackages WHERE Hash=?",(hash,))
    packages = cursor.fetchall()
    
    if len(packages)> 0:
        return True
    
    else:
        return False

def getAllPackages():
    sqliteServer = sqlite3.connect('TAK.db')
    cursor = sqliteServer.cursor()
    cursor.execute('SELECT * FROM DataPackages')
    data = cursor.fetchall()
    PackageDict = {"resultCount":len(data), "results":[]}
    for i in data:
        singlePackage = {"UID":str(i[1]), "Name": str(i[2]), "Hash": str(i[3]), "PrimaryKey":str(i[0]), "SubmissionDateTime": str(i[4]),"SubmissionUser": str(i[5]), "CreatorUid": str(i[6]), "Keywords": (i[7]), "MIMEType": str(i[8]), "Size": int(i[9])}
        PackageDict["results"].append(singlePackage)
    return PackageDict

'''
    {
    "resultCount": 1,
    "results": [{
        "UID": "uid-asdf",
        "Name": "DP-KNIGHTRIDER.zip",
        "Hash": "ee2cc3aa4f44d376c793c12870a86e4e1837282ed448f2cf61a5fb8ccc7084c3",
        "PrimaryKey": 6,
        "SubmissionDateTime": "2020-04-27-10:22:18.000Z",
        "SubmissionUser": "KNIGHTRIDER",
        "CreatorUid": "ANDROID-UID-KNIGHTRIDER",
        "Keywords": "blah",
        "MIMEType": "application/x-zip-compressed",
        "Size": 883}]
    }
'''