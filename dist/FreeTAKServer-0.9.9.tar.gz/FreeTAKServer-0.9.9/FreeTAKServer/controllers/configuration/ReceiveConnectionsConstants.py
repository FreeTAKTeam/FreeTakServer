class ReceiveConnectionsConstants:
    def __init__(self):
        self.RECEIVECONNECTIONDATATIMEOUT = 4