class ClientReceptionHandlerConstants:
    def __init__(self):
        #the smaller the number the more cpu will be used but there will also be a decrease in latency
        self.TIMEDELAYS = 0.00001