class SendHealthCheck:
    def __init__(self):
        self.xmlString = ''
        self.clientInformation = ''