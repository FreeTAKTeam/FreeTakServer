class SendInvalidCoT:
    def __init__(self):
        self.type = 'invalid'
        self.invalid = True
        self.clientInformation = ''
        self.xmlString = b''