class SendOther:
    def __init__(self):
        self.modelObject = None
        self.type = "other"
        self.clientInformation = None
        self.xmlString = None
        self.type = "other"
        self.martiPresent = False