class detailObject:
    def __init__(self):
        pass