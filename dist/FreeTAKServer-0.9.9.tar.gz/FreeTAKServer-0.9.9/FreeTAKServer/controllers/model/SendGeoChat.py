class SendGeoChat:
    def __init__(self):
        self.clientInformation = None
        self.xmlString = b''
        self.type = "GeoChat"
        self.modelObject = None