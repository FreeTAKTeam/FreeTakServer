class SendEmergency:
    def __init__(self):
        self.clientInformation = ''
        self.xmlString = ''
        self.placeInternalArray = True
        self.status = ''
        self.type = "emergency"
        self.modelObject = ''