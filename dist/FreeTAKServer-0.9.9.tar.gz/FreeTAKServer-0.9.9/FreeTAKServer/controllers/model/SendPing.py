class SendPing:
    def __init__(self):
        self.clientInformation = ''
        self.xmlString = ''
        self.type = "ping"
        self.modelObject = ''