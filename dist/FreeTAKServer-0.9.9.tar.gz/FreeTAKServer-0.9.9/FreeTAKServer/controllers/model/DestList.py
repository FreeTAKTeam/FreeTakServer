class DestList:
    def __init__(self):
        self.destList = []

    def getDestList(self):
        return self.destList

    def setDestList(self, destList):
        self.destList = destList