class socketInformation:
    def __init__(self):
        self.socketCount = int()
        self.clientArray = []