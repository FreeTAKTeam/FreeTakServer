class __group:
    def __init__(self):
        self.name = ''
        self.group = ''

    def getgroup(self):
        return self.group

    def setgroup(self, group):
        self.group = group

    def getname(self):
        return self.name

    def setname(self, name):
        self.name = name