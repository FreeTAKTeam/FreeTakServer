class vars():
   def __init__(self):
       self.PING = 'ping'
       self.GEOCHAT = 'GeoChat'
       self.FAIL = 'fail'
       self.EMPTY_BYTE = b''
       self.DEFAULTPORT = 8087
       self.LOGFILEPATH = 'path'
       self.HOSTIP = 'ip'
       self.BUFFER = 16384
