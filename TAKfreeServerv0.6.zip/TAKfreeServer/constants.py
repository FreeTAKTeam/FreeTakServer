class vars():
   def __init__(self):
       self.PING = 'ping'
       self.GEOCHAT = 'GeoChat'
       self.FAIL = 'fail'
       self.EMPTY_BYTE = b''
       self.DEFAULTPORT = 8087
       self.LOGFILEPATH = 'log.log'
       self.STARTBUFFER = 32784
       self.BUFFER =227
       self.DELAY = 5
       self.IP = '192.168.2.47'
       self.LOGTIMEFORMAT = '%(levelname)s:%(asctime)s:%(message)s'
       self.DELIMITER = ' ? '