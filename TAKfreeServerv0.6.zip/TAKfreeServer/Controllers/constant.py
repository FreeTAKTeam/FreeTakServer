
class vars:
    def __init__(self):
        self.DROPPIN = 'dropPin'
        self.GEOTOALLROOMS = 'GeoToAllRooms'
        self.GEOTOGROUP = 'GeoToGroup'
        self.GEOTOTEAM = 'GeoToTeam'
        self.PING = 'ping'