class uid:
    def __init__(self):
        Droid = ''
    def getDroid(self):
        return self.Droid
    def setDroid(self, Droid):
        self.Droid = Droid