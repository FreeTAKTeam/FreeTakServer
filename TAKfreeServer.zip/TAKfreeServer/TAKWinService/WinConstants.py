class vars():
   def __init__(self):
       self.NAME = 'FreeTAKServer'
       self.DISPLAYNAME = 'FreeTAKServer'
       self.DESCRIPTION = 'windows service version of FreeTAKService'
       self.LOGFILE = 'log.log'
       self.LOGTIMEFORMAT = '%(levelname)s:%(asctime)s:%(message)s'